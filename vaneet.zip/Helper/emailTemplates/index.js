module.exports = {
	registerProfile: require("./registerProfile").registerProfile,
	forgorPasswordAdmin: require("./forgotPasswordAdmin").forgotPasswordAdmin
};