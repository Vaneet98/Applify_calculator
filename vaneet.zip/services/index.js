module.exports= {
    profileServices: require("./profileServices"),
    plateformService:require("./plateformService"),
    addCategoryService:require("./addcategoryService"),
    adduserCategoryService:require("./adduserCategoryService"),
    industryCategoryService:require("./industryCategoryService")
  }