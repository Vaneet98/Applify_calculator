module.exports = {
  userController: require("./userController"),
  plateformController:require("./plateformController"),
  addCategoryController:require("./addcategoryController"),
  adduserCategoryController:require("./adduserCategoryController"),
  industryCategoryController:require("./industryCategoryController")
};
